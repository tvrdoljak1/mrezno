import datetime
import socket
import time
from local_machine_info import print_machine_info

start_time = time.time()

print ("Vrijeme pokretanja programa:")
print (datetime.datetime.now())
print ("Program se ivodi:")
print_machine_info()

print ("===============================================")
print ("Molim vas unesite adresu hosta:")
target = raw_input(">> ")
targetIP = socket.gethostbyname(target)
print ("Skeniranje host %s, IP adresu: $s" % (target, targetIP))
print ("Unesite od kojeg do kojeg porta zelite napraviti skeniranje:")
start = raw_input("Pocetni port >> ")
end = raw_input("Zavrsni port >> ")

for PortNumber in range(int(start),int(end)+1):
	tcp_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	print ("Skeniranje porta: %d" % PortNumber)
	result = tcp_sock.connect_ex((targetIP,PortNumber))
	if result == 0:
		print ("Port %d je otvoren" % PortNumber)
	tcp_sock.close()
	
elapsed_time = time.time() - start_time

print ("Skeniranje portova zavrseno!")
print ("Vrijeme: %s " % elapsed_time)
	
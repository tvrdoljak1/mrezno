

import socket
import datetime
 

test = raw_input()
clientMessage = "Hello UDP Server"
serverAddresPort = 9999
sentBytes = str.encode(clientMessage )
serverAddresIP = socket.gethostname()
bufferSize = 1024
serverAddresCon = (serverAddresIP, serverAddresPort)


UdpClientSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
UdpClientSocket.sendto(sentBytes , serverAddresCon)
serverMessage = UdpClientSocket.recvfrom(bufferSize)
 
message = "message from server {} ".format(serverMessage[0])

print(message)
print datetime.datetime.now()
print 'Unesi string'


if test == 'aspira':
	print 'unreachabel!'
if test != 'aspira':
	print "Connected to: %s" %(test)
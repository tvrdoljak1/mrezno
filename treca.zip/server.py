

import socket
import datetime
from local_machine_info import print_machine_info 
 

 
IPaddress = socket.gethostname()
port = 9999
bufferSize = 1024

serverMessage = "Hello UDP Client"
sentBytes = str.encode(serverMessage )


UdpServerSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
UdpServerSocket.bind((IPaddress, port))


print("Udp server up and listening")
print datetime.datetime.now()
print_machine_info()

while(True):

    bytesAddressPair = UdpServerSocket.recvfrom(bufferSize)

    message = bytesAddressPair[0]
    address = bytesAddressPair[1]
	
    clientMessage = "Message from Client:{}".format(message)
    clientIP  = "Client IP Address:{}".format(address)
    
    print(clientMessage)
    print(clientIP)
   
    UDPServerSocket.sendto(sentBytes , address)